function [ out ] = Ugranular( dist,m )
%The membership degree
% out = zeros(size(dist,1),size(dist,2));
tmp = dist.^(-2/(m-1)); 
% for i = 1:size(dist,2)
%     if any(dist(:,6)==0) == 1
%         tmp(dist(:,6)==0,i) = 1;
%     end    
% end
out = tmp./(ones(size(dist,1), 1)*sum(tmp));
out(isnan(out)) = 1;
end
