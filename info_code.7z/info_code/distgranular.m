function [out_low, out_up, point_low, point_up] = distgranular( V_bound, data )
%Distance measure in granular data
out_low = zeros(size(V_bound, 1), size(data, 1));
out_up = out_low;
point_low = cell(size(V_bound, 1),size(data,1));
point_up = point_low;
std_data = std(data);
% std_data = ones(1,size(std_data,2));
for k = 1:size(V_bound, 1)
    bound = V_bound{k};
    for n = 1:size(data,1)
        sign_all = sign(data(n,:)-bound(1,:))+sign(bound(2,:)-data(n,:));
        temp_p_low = zeros(1,size(data,2));
        temp_p_up = temp_p_low;
        if isempty(find(sign_all~=0, 1)) == 1
          temp_p_low(1,sign(data(n,:)-bound(1,:)) == -1) = bound(1,sign(data(n,:)-bound(1,:)) == -1);
          temp_p_low(1,sign(data(n,:)-bound(1,:)) == 1) = bound(2,sign(data(n,:)-bound(1,:)) == 1);
          temp_p_up(1,sign(bound(2,:)-data(n,:)) == 1) = bound(2,sign(bound(2,:)-data(n,:)) == 1);
          temp_p_up(1,sign(bound(2,:)-data(n,:)) == -1) = bound(1,sign(bound(2,:)-data(n,:)) == -1);
        elseif sum(sign_all == 2) == size(data,2)
            temp_p_low = data(n,:);
            temp_p_up = data(n,:);
        else
          temp_p_low(1,sign(data(n,:)-bound(1,:)) == -1) = bound(1,sign(data(n,:)-bound(1,:)) == -1);
          temp_p_low(1,sign(data(n,:)-bound(1,:)) == 1) = bound(2,sign(data(n,:)-bound(1,:)) == 1);
          temp_p_up(1,sign(bound(2,:)-data(n,:)) == 1) = bound(2,sign(bound(2,:)-data(n,:)) == 1);
          temp_p_up(1,sign(bound(2,:)-data(n,:)) == -1) = bound(1,sign(bound(2,:)-data(n,:)) == -1);
          temp_p_low(sign_all == 2) = data(n,sign_all == 2);
          temp_p_up(sign_all == 2) = data(n,sign_all == 2);
        end
        out_low(k,n) = sqrt(sum((temp_p_low-data(n,:)).^2./(std_data).^2));    
        out_up(k,n) = sqrt(sum((temp_p_up-data(n,:)).^2./(std_data).^2));
        point_low{k,n} = temp_p_low;
        point_up{k,n} = temp_p_up;
    end
end
end
%     out(k, :) = sqrt(sum(((data-ones(size(data, 1), 1)*center(k, :)).^2)'));
