% clc
% clear
% 
load synthetic.mat
load synthetic_fold.mat
Data = synthetic;
% % load('house_cen_func3.mat')
% pathname = ['C:\Users\Admin\Desktop\new_experience\synthetic\']


%  global D  trn_inputs trn_targets tst_inputs tst_targets c_num fold Vi   c  Wi
c_all = [3,5,7];
epsi_all=[0.01,0.02,0.03,0.04,0.05,0.06,0.07,0.08,0.09,0.1];%0.083 0.067
times = 5; 
m = 2;
for fold = 2:times
    
    
    Train_flag = Trainflag{fold};
    Test_flag = Testflag{fold};
    
    Train_data = Data(Train_flag,:);
    Test_data = Data(Test_flag,:);
    
    trn_inputs = Train_data(:,1:end-1);
    trn_targets = Train_data(:,end);
    
    tst_inputs = Test_data(:,1:end-1);
    tst_targets = Test_data(:,end);
    
    Trn_Num = size(Train_data,1);
    Tst_Num = size(Test_data,1);
    for c_num = 1:length(c_all)
        %% -------------------------------Numerical fuzzy rule-based model-------------------------------------------------   

        c = c_all(c_num);
        options = [m 200 1e-5 false];
        [center, ~,~] = fcm(Train_data,c,options);
        Vi = center(:,1:end-1);
        Wi = center(:,end);

        [y_trn,a] = func3(Vi,Wi,trn_inputs,m,trn_targets);
        RMSE_trn = (norm(y_trn-trn_targets)/sqrt(size(trn_targets,1)));
        
        %% -----------------------------------Optimization of prototypes---------------------------------------------------
        problem_size = c*(size(Vi,2)+1);
        
        lb = reshape(repmat(min(Train_data),c,1)-[Vi Wi],1,[]);
        ub = reshape(repmat(max(Train_data),c,1)-[Vi Wi],1,[]);
        max_fval = inf;
        for tryi = 1:1
            % population setting
            pop_size = 200;
            pop2 = repmat(lb,pop_size,1) + rand(pop_size,problem_size).*(repmat(ub-lb,pop_size,1));

            fun2 = @(xx) obj_func_prototype(Vi,Wi,xx,trn_inputs,m,trn_targets);%'Initialswarm',pop2,
            options = optimoptions('particleswarm','SwarmSize',pop_size,'Initialswarm',pop2,'MaxIter',600);%'InertiaRange',[0.9,0.9],'SelfAdjustmentWeight',0.5,'SocialAdjustmentWeight',0.3,'Display','off'
            [solution,fval2,exitflag,output] = particleswarm(fun2,problem_size,lb,ub,options);
%             if fval2<max_fval
%                 max_fval = fval2;
%                 solution_v_tmp{cnum} = solution;
%                 %                     Fvals_all_v_tmp{i,cnum} = Fvals_all2;
%             end
        end
        v_solution = solution;
        center_opt = reshape(v_solution,c,[]) +[Vi,Wi];
        V_opt = center_opt(:,1:end-1);
        W_opt = center_opt(:,end);
        %------------------------------train set after Optimization-------------------------------------
        [y_trn_optV,a] = func3(V_opt,W_opt,trn_inputs,m,trn_targets);
        RMSE_trn_Vopt = (norm(y_trn_optV-trn_targets)/sqrt(size(trn_targets,1)));
        
        %------------------------------testing set after Optimization----------------------------------------
        Mem_tst = partition_matrix(V_opt,tst_inputs,m);
        tst_zz = [];
        for ii=1:size(V_opt,1)
            tst_zz =[ tst_zz [repmat(Mem_tst(ii,:),size(tst_inputs,2),1)'.*(tst_inputs-repmat(V_opt(ii,:),size(tst_inputs,1),1))]];
        end
        q_tst = Mem_tst'*W_opt;
        y_tst_Vopt =q_tst + tst_zz*a;
        RMSE_tst_Vopt = (norm(y_tst_Vopt-tst_targets)/sqrt(size(tst_targets,1)));
        
%% -------------------------------Granular model--------------------------------------------------        
        %----------------------------------------------the allocation of Information granularity ----------------------------------------------------------
        range = max(trn_inputs)-min(trn_inputs);
        range_y = max(trn_targets)-min(trn_targets);
        granular_opt_size = 2*c*(size(Vi,2)+1);
        for ij = 1: length(epsi_all)
            epsi = epsi_all(ij);
            max_fval = inf;
            for tryi = 1:1
                % population setting
                pop_size = 100;
                pop3 = rand(pop_size,granular_opt_size);

                fun3 = @(epsixx) obj_func_granular(epsixx,V_opt,W_opt,trn_inputs,trn_targets,a,m,c,epsi,range,range_y);

                options2 = optimoptions('particleswarm','Initialswarm',pop3,'SwarmSize',pop_size,'MaxIter',200);%'FunctionTolerance',1e-2
                [solution2,~,~,~] = particleswarm(fun3,granular_opt_size,[],[],options2);
                %             if fval2<max_fval
                %                 max_fval = fval2;
                %                 solution_v_tmp{cnum} = solution;
                %                 %                     Fvals_all_v_tmp{i,cnum} = Fvals_all2;
                %             end
            end
            epsi_opt  = solution2;
            %-------------------------------------------------train set-------------------------------------------------------------------------
            [trn_cov,trn_spe,trn_y_minus,trn_y_plus]= func_output(epsi_opt,V_opt,W_opt,trn_inputs,trn_targets,a,m,c,epsi,range,range_y);
            %-------------------------------------------------testing set--------------------------------------------------------------------------
            [tst_cov,tst_spe,tst_y_minus,tst_y_plus]= func_output(epsi_opt,V_opt,W_opt,tst_inputs,tst_targets,a,m,c,epsi,range,range_y);
            
            epsi_info{c_num,ij} = epsi_opt;
            TrnCov_epsi(c_num,ij) = trn_cov;
            TrnSpe_epsi(c_num,ij) = trn_spe;
            TstCov_epsi(c_num,ij) = tst_cov;
            TstSpe_epsi(c_num,ij) = tst_spe;
            Trn_Q(c_num,ij) = trn_cov*trn_spe;Tst_Q(c_num,ij) = tst_cov*tst_spe;
        end
        %TrnRMSE(fold,c_num) = RMSE_trn; 
        TrnRMSE_opt(fold,c_num) = RMSE_trn_Vopt; 
        TstRMSE_opt(fold,c_num) = RMSE_tst_Vopt;         
    end
    Gtrn{1,fold} = TrnCov_epsi;
    Gtrn{2,fold} = TrnSpe_epsi;
    Gtst{1,fold} = TstCov_epsi;
    Gtst{2,fold} = TstSpe_epsi;
    G_Q{1,fold} = Trn_Q;G_Q{2,fold} = Tst_Q;
end
        
          