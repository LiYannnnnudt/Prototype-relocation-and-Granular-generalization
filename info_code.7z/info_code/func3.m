function [output,a]  = func3(Vi,Wi,trn_inputs,mm,trn_targets)

    Mem = partition_matrix(Vi,trn_inputs,mm);
    row = size(Vi,1);
    trn_zz = [];
    for ii=1:row
        trn_zz =[ trn_zz [repmat(Mem(ii,:),size(trn_inputs,2),1)'.*(trn_inputs-repmat(Vi(ii,:),size(trn_inputs,1),1))]];
    end
    q = Mem'*Wi;
    p = trn_targets-Mem'*Wi;
    a  = pinv(trn_zz'*trn_zz)*trn_zz'*p;
    output =q+ trn_zz*a;

end      