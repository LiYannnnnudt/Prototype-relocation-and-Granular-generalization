function [y_min,y_plus]= granular_out(inputs, V_low,V_up,U_minus, U_plus,a,W_minus, W_plus,mm)

y_min = zeros(size(inputs,1),1);
y_plus = y_min;


  for k = 1:size(inputs,1)
    for i = 1:size(U_minus,1)  
       xV_minus = inputs(k,:)-V_low(i,:);
       xV_plus = inputs(k,:)-V_up(i,:);
       axV_minus = a(:,i)'*xV_minus';
       axV_plus = a(:,i)'*xV_plus';
       
       BWaxV_minus(i) = U_minus(i,k)*(axV_minus+W_minus(i));
       BWaxV_plus(i) = U_plus(i,k)*(axV_plus+W_plus(i));
    end
    y_low(k) = sum(BWaxV_minus);
    y_up(k) = sum(BWaxV_plus);
  end
  
  y_min = min(y_low,y_up);
  y_plus = max(y_low,y_up);
end
