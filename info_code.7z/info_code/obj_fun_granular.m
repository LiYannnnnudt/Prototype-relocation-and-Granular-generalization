function [y_min, y_plus] = obj_fun_granular(TrainData_x, U_minus, U_plus,a,W_minus, W_plus,point_low,point_up)
%object funtion
BWaxV_minus = zeros(1,size(U_minus,1));
BWaxV_plus = BWaxV_minus;
y_min = zeros(size(TrainData_x,1),1);
y_plus = y_min;
for k = 1:size(TrainData_x,1)
    for i = 1:size(U_minus,1)
        xV_minus = TrainData_x(k,:)-point_low{i,k};
        xV_plus = TrainData_x(k,:)-point_up{i,k};
        axV_minus = min(a(:,i)'*xV_minus',a(:,i)'*xV_plus');
        axV_plus = max(a(:,i)'*xV_minus',a(:,i)'*xV_plus');
        BWaxV_minus(i) = min([U_minus(i,k)*(axV_minus+W_minus(i)),U_minus(i,k)*(axV_plus+W_plus(i)),U_plus(i,k)*(axV_minus+W_minus(i)),U_plus(i,k)*(axV_plus+W_plus(i))]);
        BWaxV_plus(i) = max([U_minus(i,k)*(axV_minus+W_minus(i)),U_minus(i,k)*(axV_plus+W_plus(i)),U_plus(i,k)*(axV_minus+W_minus(i)),U_plus(i,k)*(axV_plus+W_plus(i))]);
    end
    y_min(k) = sum(BWaxV_minus);
    y_plus(k) = sum(BWaxV_plus);
end
end