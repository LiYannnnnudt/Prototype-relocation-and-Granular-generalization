times = 5;%
percent = 0.8;
N = 500;
%[N,d] = size(X);% the number of data
for fold = 1:times
% clc
% % clear
num = N;
i = 1;
j = 1;
index = sort(randperm(num,round(num*percent)));
% Train_flag = index;
for n=1:num
    if n == index(i)
        Train_flag(i) = n;
        if i<round(num*percent)
            i = i+1;
        end
    else
        Test_flag(j) = n;
        j = j+1;
    end
end
Trainflag{fold} = Train_flag;%the index of train set 
Testflag{fold} = Test_flag;%the index of testing set 
end
%save('C:\Users\Admin\Desktop\new_experience\QSAR\flag_qsar.mat','Trainflag','Testflag')