function Q = obj_func_prototype(Vi,Wi,xx,trn_inputs,m,targets)
% the objective function for the optimization of prototypes
% xx : c*d+c
%

    c = size(Vi,1);

    center = reshape(xx,c,[]) +[Vi,Wi];
    V_tmp = center(:,1:end-1);
    W_tmp = center(:,end);

    Mem = partition_matrix(V_tmp,trn_inputs,m);
    row = size(V_tmp,1);
    trn_zz = [];
    for ii=1:row
        trn_zz =[ trn_zz [repmat(Mem(ii,:),size(trn_inputs,2),1)'.*(trn_inputs-repmat(V_tmp(ii,:),size(trn_inputs,1),1))]];
    end
    q = Mem'*W_tmp;
    p = targets-Mem'*W_tmp;
    a  = inv(trn_zz'*trn_zz)*trn_zz'*p;
    y_trn =q+ trn_zz*a;

    Q = (norm(y_trn-targets)/sqrt(size(targets,1)));

end