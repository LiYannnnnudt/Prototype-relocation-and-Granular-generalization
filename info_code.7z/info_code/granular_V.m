function out = granular_V( V,xx,D,range )
% make the cluster center granular
% out = cell(size(V,1));
xx = reshape(xx,size(V,1),[]);
xx(:,1:2:end) = -1*xx(:,1:2:end);
temp_V_bound = cell(size(V,1),1);
for k = 1:size(V,1)
   bound(1,:) = V(k,:)+range.*xx(k,1:2:2*(D-1)-1);
   bound(2,:) = V(k,:)+range.*xx(k,2:2:2*(D-1));
   temp_V_bound{k} = bound;
end
out = temp_V_bound;
end