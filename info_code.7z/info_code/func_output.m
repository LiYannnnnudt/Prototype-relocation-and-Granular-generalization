function [cov, spe,y_minus,y_plus]= func_output(epsixx,V,W,inputs,targets,a,mm,c,epsi,range,range_y)
% The Construction of granular model
% The allocation of Information Granularity
% Information Granularity: epsixx:(c*d+c)*2

    D = size(V,2)+1;
    xx = condition(epsixx,epsi); 
    a = reshape(a',D-1,[]);  
    granualr_V = granular_V(V,xx(1:(D-1)*c*2),D,range);
    [W_minus, W_plus] = granular_W(W,xx((D-1)*c*2+1:end),range_y);
    [dist_low,dist_up, point_low, point_up] = distgranular(granualr_V, inputs);%||Xk-Vi||
    U_low = Ugranular(dist_low,mm);
    U_up = Ugranular(dist_up,mm);
    [U_minus, U_plus] = compare_U( U_low, U_up );
    
    [y_minus,y_plus ]= obj_fun_granular(inputs, U_minus, U_plus,a,W_minus, W_plus,point_low,point_up);
    
    cov = 0;
    k=0;
    for i = 1:size(targets,1)
        if targets(i)<=y_plus(i) && targets(i)>=y_minus(i)
            k = k+1;
        end
    end
    cov = k/size(targets,1);
    spe = nanmean(exp(-abs(y_plus-y_minus)));
   
    
end