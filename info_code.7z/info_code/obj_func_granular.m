function Q= obj_func_granular(epsixx,V,W,inputs,targets,a,mm,c,epsi,range,range_y)
% the objective function for information granularity    
%
%
   [cov, spe,~,~]= func_output(epsixx,V,W,inputs,targets,a,mm,c,epsi,range,range_y);
    Q = - cov*spe;  
  %  Q =1/Q+1;
    
end