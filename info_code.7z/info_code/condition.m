function y = condition(epsi_i,epsi)
if sum(epsi_i) == 0
    y = zeros(1,size(epsi_i,2));
else
    y = epsi_i/sum(epsi_i)*epsi;
end
end
