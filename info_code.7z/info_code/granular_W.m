function [ w1, w2 ] = granular_W( w, e,range_y)
%make it granular by admitting a certain level of information granularity
e = reshape(e,[],2);
w = reshape(w,1,[]);
w1 = zeros(1,size(w,2));
w2 = zeros(1,size(w,2));
for i = 1:size(w,2)
        w1(i) = min(w(i)-range_y*e(i,1),w(i)+range_y*e(i,1));
        w2(i) = max(w(i)-range_y*e(i,1),w(i)+range_y*e(i,1));
end
end