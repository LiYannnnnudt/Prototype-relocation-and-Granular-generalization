function [y1, y2] = compare_U( x1, x2 )
%rank minus and plus
y1 = zeros(size(x1,1),size(x1,2));
y2 = y1;
for i = 1:size(x1,1)
    for j = 1:size(x1,2)
        y1(i,j) = min(x1(i,j),x2(i,j));
        y2(i,j) = max(x1(i,j),x2(i,j));
    end
end    
end
